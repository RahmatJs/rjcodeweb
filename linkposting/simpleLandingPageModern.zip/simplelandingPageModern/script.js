const navbar = document.querySelector(".navbar-nav");
const bars = document.getElementById("icn-bars");

bars.addEventListener("click", () => {
    navbar.classList.toggle("active");
    document.body.classList.toggle("no-scroll");
});
