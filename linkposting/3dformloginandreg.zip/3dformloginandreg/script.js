const btnStart = document.getElementById("btn-start");
const startForm = document.querySelector(".start-form");
const containerHook = document.querySelector(".hook");
const iconSilang = document.getElementById("icn-x");

const signupFlip = document.getElementById("signup-flip");
const signinFlip = document.getElementById("signin-flip");
const cardFlip = document.querySelector(".card");

btnStart.addEventListener("click", () => {
    containerHook.classList.add("slide");
    startForm.classList.add("active");
});
iconSilang.addEventListener("click", () => {
    containerHook.classList.remove("slide");
    startForm.classList.remove("active");
});

signupFlip.addEventListener("click", function(e)  {
    e.preventDefault();
    cardFlip.classList.add("active");
});

signinFlip.addEventListener("click", function(e)  {
    e.preventDefault();
    cardFlip.classList.remove("active");
});