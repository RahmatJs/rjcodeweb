const btnLogin = document.getElementById("btn-login");
const form = document.getElementById("form");
const closeForm = document.getElementById("close-form");
const main = document.getElementById("main");
const regBtn = document.getElementById("reg-btn");
const lgnBtn = document.getElementById("lgn-btn");
const login = document.querySelector(".login")
const register = document.querySelector(".register")

btnLogin.addEventListener("click", () => {
    form.classList.add("active");
    form.classList.remove("hForm");
    main.classList.add("blur");
});
closeForm.addEventListener("click", () => {
    form.classList.remove("active");
    form.classList.add("hForm");
    main.classList.remove("blur");
});

regBtn.addEventListener("click", function (e) {
    e.preventDefault();
    register.classList.add("act");
    login.classList.add("hide");
});
lgnBtn.addEventListener("click", function (e) {
    e.preventDefault();
    register.classList.remove("act");
    login.classList.remove("hide");
});


const menu = document.getElementById("menu");
const closeBar = document.getElementById("close-bar");
const navbar = document.querySelector(".navbar-nav");

menu.addEventListener("click", () => {
    navbar.classList.add("act");
    document.body.classList.add("no-scroll")
});
closeBar.addEventListener("click", () => {
    navbar.classList.remove("act")
    document.body.classList.remove("no-scroll")
});

