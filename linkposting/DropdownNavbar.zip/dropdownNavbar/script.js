const dropdown = document.querySelector('.dropdown > a');

dropdown.addEventListener('click', function (e) {
  e.preventDefault();
  this.nextElementSibling.classList.toggle('show');
});