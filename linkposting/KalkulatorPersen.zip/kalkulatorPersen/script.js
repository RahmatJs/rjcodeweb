function hitungPersentase() {
const persen = document.getElementById("persen").value;
const angka = document.getElementById("angka").value;
const hasil = document.getElementById("hasil");
const notifKosong = document.getElementById("notif");

 if (!angka || !persen) {
    notifKosong.innerText = "Harap Isi Terlebih Dahulu!";
    notifKosong.style.color = 'red';
    notifKosong.style.textAlign = 'center';
    return;
 }

 const hasilPersen = (persen / 100) * angka;
 hasil.textContent = `jadi, ${persen}% dari ${angka} = ${hasilPersen}`;
 hasil.style.textAlign = 'center';
 hasil.style.marginTop = '20px';

}