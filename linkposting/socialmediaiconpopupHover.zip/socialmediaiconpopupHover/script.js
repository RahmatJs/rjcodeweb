const iconfb = document.querySelector(".icn-fb");
const icontw = document.querySelector(".icn-tw");
const iconig = document.querySelector(".icn-ig");
const icongt = document.querySelector(".icn-gt");
const iconyt = document.querySelector(".icn-yt");

const deskFb = document.querySelector(".fB")
const deskTw = document.querySelector(".tw")
const deskIg = document.querySelector(".ig")
const deskGt = document.querySelector(".gt")
const deskYt = document.querySelector(".yt")

iconfb.addEventListener("mouseover", () => {
    deskFb.classList.add("active");
});
iconfb.addEventListener("mouseout", () => {
    deskFb.classList.remove("active");
});

icontw.addEventListener("mouseover", () => {
    deskTw.classList.add("active");
});
icontw.addEventListener("mouseout", () => {
    deskTw.classList.remove("active");
});

iconig.addEventListener("mouseover", () => {
    deskIg.classList.add("active");
});
iconig.addEventListener("mouseout", () => {
    deskIg.classList.remove("active");
});

icongt.addEventListener("mouseover", () => {
    deskGt.classList.add("active");
});
icongt.addEventListener("mouseout", () => {
    deskGt.classList.remove("active");
});

iconyt.addEventListener("mouseover", () => {
    deskYt.classList.add("active");
});
iconyt.addEventListener("mouseout", () => {
    deskYt.classList.remove("active");
});





