const email = document.getElementById("email");
const password = document.getElementById("password");
const emailMsg = document.getElementById("emailMsg");
const passMsg = document.getElementById("passMsg");
const btnDaftar = document.getElementById("btn-daftar");
const inputNull = document.getElementById("valid-form");

btnDaftar.addEventListener("click", function() {
    if (email.value === "") {
        inputNull.textContent = "Harap isi form terlebih dahulu";
        inputNull.className = 'message error';
        setTimeout(() => {
            inputNull.style.display = 'none';
        }, 3000);
    } 
});

email.addEventListener("input", () => {
    const value = email.value;

    if (!value.includes('@')) {
        emailMsg.textContent = 'Email harus mengandung @';
        emailMsg.className = 'message error';
    } else if (value.includes('gmial')) {
        emailMsg.textContent = 'Maksud kamu Gmail.com';
        emailMsg.className = 'message error';
    } else {
        emailMsg.textContent = 'Email Valid'
        emailMsg.className = 'message success'
    }
});

password.addEventListener("input", () => {
    const value = password.value;

    if (value.length < 6) {
        passMsg.textContent = 'Password minimal 6 karakter !';
        passMsg.className = 'message error';
    } else if (!/[0-9]/.test(value)) {
        passMsg.textContent = 'Tambahkan angka agar password kuat';
        passMsg.className = 'message error';
    } else if (!/[#$!^*&]/.test(value)) {
        passMsg.textContent = 'Gunakan tanda khusus (#, $, !, ^, *, &)';
        passMsg.className = 'message error';
    }  else {
        passMsg.textContent = 'Password Kuat';
        passMsg.className = 'message success';
    }    
   
});

const closeEye = document.getElementById("eye-close");

closeEye.addEventListener("click", () => {
    if (password.type == 'password') {
        password.type = 'text';
        closeEye.classList.add('fa-eye');
    } else {
        password.type = 'password';
        closeEye.classList.remove('fa-eye');
    }
});