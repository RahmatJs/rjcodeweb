const password = document.getElementById("password");
const close_eye = document.getElementById("eye-close");

close_eye.addEventListener("click", () => {
    if (password.type == 'password') {
        password.type = 'text';
        close_eye.classList.add('fa-eye');
    } else {
        password.type = 'password';
        close_eye.classList.remove('fa-eye');
    }
});

// const test = document.querySelector(".test");
const passCharacter = document.getElementById("passMsgCharacter");
const passAZ = document.getElementById("passMsgA-Z");
const passaz = document.getElementById("passMsga-z");
const passNumber = document.getElementById("passMsgNumber");
const passSymbol = document.getElementById("passMsgSymbol");
const passSpace = document.getElementById("passMsgSpace");

password.addEventListener("input", () => {
    const value = password.value

    if (value.length >= 8 ) {
        passCharacter.style.color = "#4BDB4B";
    } else {
        passCharacter.style.color = "red";
    }
   
    if (/[A-Z]/.test(value)) {
        passAZ.style.color = "#4BDB4B";
    } else {
        passAZ.style.color = "red";
    }

    if (/[a-z]/.test(value)) {
        passaz.style.color = "#4BDB4B";
    } else {
        passaz.style.color = "red";
    }

    if (/[0-9]/.test(value)) {
        passNumber.style.color = "#4BDB4B";
    } else {
        passNumber.style.color = "red";
    }

    if (/[" "]/.test(value)) {
        passSpace.style.color = "#4BDB4B";
    } else {
        passSpace.style.color = "red";
    }

    if (/[!@#$%^&*()]/.test(value)) {
        passSymbol.style.color = "#4BDB4B";
    } else {
        passSymbol.style.color = "red";
    }

});
