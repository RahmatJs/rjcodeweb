

let inputPassword = document.getElementById('password');
let eyeIcon = document.getElementById('eye-close');

eyeIcon.onclick = function(){
    if(inputPassword.type == 'password'){
        inputPassword.type = 'text';
        eyeIcon.src = "gambar/eye-open.png";
    }else{
        inputPassword.type = 'password';
        eyeIcon.src = "gambar/eye-close.png";
    }
};