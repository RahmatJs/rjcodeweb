// jika hanya satu baris kalimat

// const text = [
//     "Welcome to RJ Code",
//     "Learn Coding With Simple Project",
//     "Best JavaScript Project"
// ];

// const speed = 150;

// let index = 0;

// function effect(){
//     if(index < text.length) {
//         document.getElementById("typing").innerHTML += text.charAt(index);

//         index++;

//         setTimeout(effect, speed);
//     }
// }
// effect();





// baris pertama di hapus dan baris kedua muncul dst

// const text = [
//     "Welcome to RJ Code",
//     "Learn Coding With Simple Project",
//     "Best JavaScript Project"
// ];

// let textIndex = 0;
// let charIndex = 0;

// const speed = 150;
// const eraseSpeed = 50;
// const delay = 1500;
// const typingElement = document.getElementById("typing");

// function animation(){
//     if(charIndex < text[textIndex].length) {
//         typingElement.innerHTML += text[textIndex].charAt(charIndex);

//         charIndex++;

//         setTimeout(animation, speed);
//     }else{
//         setTimeout(eraseText, delay);
//     }
// }

// function eraseText(){
//     if(charIndex > 0) {
//         typingElement.innerHTML = text[textIndex].substring(0,charIndex-1);

//         charIndex--;

//         setTimeout(eraseText, eraseSpeed);
//     }else{
//         textIndex++;

//         if (textIndex >= text.length){
//             textIndex = 0;
//         }
//         setTimeout(animation, speed);
//     }
// }

// animation();


// baris muncul satu persatu secara bergiliran
const text = [
    "Welcome to RJ Code",
    "Learn Coding With Simple Project",
    "Best JavaScript Project",
    "Part 3",
    "Text Typing Animation In HTML, CSS, JavaScript"
];

let textIndex = 0;
let charIndex = 0;

const speed = 130;

const typing = document.getElementById("typing");

function animation(){
    if(charIndex < text[textIndex].length){
        typing.innerHTML += text[textIndex].charAt(charIndex);

        charIndex++;

        setTimeout(animation, speed);
    } else {
        typing.innerHTML += "<br>";

        textIndex++;
        charIndex = 0;

        if(textIndex < text.length){
            setTimeout(animation, 500);
        }
    }
}
animation();
