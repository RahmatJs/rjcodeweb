const btnSignup = document.getElementById("btn-signup");
const register = document.querySelector(".form-register");
const login = document.querySelector(".form-login");
const btnLogin = document.getElementById("btn-login");

btnSignup.addEventListener("click", function (e) {
    e.preventDefault();
    register.classList.add("active");
    login.classList.add("hide");
});

btnLogin.addEventListener("click", function (e) {
    e.preventDefault();
    register.classList.remove("active");
    login.classList.remove("hide");
});